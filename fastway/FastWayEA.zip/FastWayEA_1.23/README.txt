README — FastWay EA: Expert Advisor Package
==========================================================

Version: 1.23  
Last updated: July 2025

This archive contains the compiled Expert Advisor (EA) **FastWay EA**, several ready-made preset files, the server configuration needed for WebRequest, **and** a shortcut to the full PDF manual.  
It is intended for users who want to install and run the EA in their MetaTrader 5 (MT5) terminal.

Directory Structure
-------------------

1. /
   - **FastWay EA.ex5**  
     → Compiled EA file for the MetaTrader 5 platform  

   - **server.txt**  
     → Server URL that must be added to the **Allowed WebRequest URLs** list in MT5  

   - **FastWayEA-Setup_guide.url**  
     → Windows shortcut that opens the full PDF installation & usage manual in your web-browser

2. **/Set-files/**
   - **FW medium (default) (AY81-DD43) – 1500 USD min balance.set**  
     → Recommended balance-risk preset (baseline)  

   - **FW low risk (AY41-DD25) – 2500 USD min balance.set**  
     → Extra-cautious mode for larger deposits  

   - **FW high risk (AY200-DD83) – 800 USD min balance.set**  
     → Aggressive growth with higher drawdown tolerance  

   - **Non-Compounding (base 10 000 USD) – FW medium risk.set**  
     → Medium-risk strategy without lot compounding, designed for ~10 k USD starting equity  

*(Place all `.set` files exactly in this **/Set-files/** folder; load your chosen preset from the EA’s properties window.)*

server.txt Instructions
-----------------------

1. Open MT5.  
2. Go to **Tools → Options → Expert Advisors**.  
3. In **Allowed WebRequest URLs**, paste the URL from `server.txt`.  
4. Click **OK** and restart MT5 if necessary.

Shortcut / PDF Manual
---------------------

- Double-click **FastWayEA-Setup_guide.url**.  
- Your default browser will open the official **PDF manual**, covering detailed installation, parameter descriptions, examples, and troubleshooting.  
  *(If the shortcut doesn’t open, right-click → “Open” or copy the URL inside the file into your browser.)*

Usage Notes
-----------

- FastWay EA can run **out of the box** with default parameters, or you can load any `.set` file from **/Set-files/** to match your risk profile.  
- Strategy: smart mean-reversion with built-in risk filters (ATR, S&P 500, volatility spikes, etc.).  
- One-chart setup is enough; multi-chart mode is optional.  
- For best execution, use an **ECN / RAW-spread account** with leverage 1:100 or higher.  
- Always back-test or demo-test before going live.

⚠️ Risk Warning:
Trading Forex & CFDs carries a high level of risk. Past performance is **not** a guarantee of future results.  
Use capital you can afford to lose and monitor drawdowns closely.

Author: **PAVELUDO**  
Website: <https://paveludo.com>  
Telegram: <https://t.me/PAVELUDO>
