README — MultiWay EA: Expert Advisor Package
==========================================================

Version: 1.12  
Last updated: October 2025

This archive contains the compiled Expert Advisor (EA) **MultiWay EA**, several ready-made preset files, the server configuration needed for WebRequest, **and** a shortcut to the full PDF manual.  
It is intended for users who want to install and run the EA in their MetaTrader 5 (MT5) terminal.

Directory Structure
-------------------

1. /
   - **MultiWay EA.ex5**  
     → Compiled EA file for the MetaTrader 5 platform  

   - **server.txt**  
     → Server URL that must be added to the **Allowed WebRequest URLs** list in MT5  

   - **MultiWayEA-Setup_guide.url**  
     → Windows shortcut that opens the full PDF installation & usage manual in your web-browser

2. **/Set-files/**
   - **MultiWay Medium Risk (default) (AY117-DD40) 3000 USD min balance.set**  
     → Recommended balance-risk preset (baseline)  

   - **MultiWay Low Risk (AY48-DD20) 6000 USD min balance.set**  
     → Extra-cautious mode for larger deposits  

   - **MultiWay High Risk (AY333-DD79) 1500 USD min balance.set**  
     → Aggressive growth with higher drawdown tolerance  

   - **Non-Сompounding (base 10000 USD) - MultiWay Medium Risk.set**  
     → Medium-risk strategy without lot compounding, designed for ~10 k USD starting equity  

*(Place all `.set` files exactly in this **/Set-files/** folder; load your chosen preset from the EA’s properties window.)*

server.txt Instructions
-----------------------

1. Open MT5.  
2. Go to **Tools → Options → Expert Advisors**.  
3. In **Allowed WebRequest URLs**, paste the URL from `server.txt`.  
4. Click **OK** and restart MT5 if necessary.

Shortcut / PDF Manual
---------------------

- Double-click **MultiWayEA-Setup_guide.url**.  
- Your default browser will open the official **PDF manual**, covering detailed installation, parameter descriptions, examples, and troubleshooting.  
  *(If the shortcut doesn’t open, right-click → “Open” or copy the URL inside the file into your browser.)*

Usage Notes
-----------

- MultiWay EA can run **out of the box** with default parameters, or you can load any `.set` file from **/Set-files/** to match your risk profile.  
- Strategy: advanced mean-reversion with dynamic market-phase filters (volatility, trend detection, macro filters, etc.).  
- One-chart setup is enough; multi-chart mode is optional.  
- For best execution, use an **ECN / RAW-spread account** with leverage 1:100 or higher.  
- Always back-test or demo-test before going live.

⚠️ Risk Warning:
Trading Forex & CFDs carries a high level of risk. Past performance is **not** a guarantee of future results.  
Use capital you can afford to lose and monitor drawdowns closely.

Author: **PAVELUDO**  
Website: <https://paveludo.com>  
Telegram: <https://t.me/PAVELUDO>
